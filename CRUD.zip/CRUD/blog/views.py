from django.shortcuts import render, get_list_or_404, get_object_or_404
#from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.db.models import Q

# Create your views here.

from .models import PostModel
from .forms import PostModelForm




#@login_required
def post_model_delete_view(request, id=None):
    obj = get_object_or_404(PostModel, id=id)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'Delete Post!')
        return HttpResponseRedirect('/blog/')

    context = {
        'objects': obj,
    }
    template = 'blog/delete_view.html'
    return render(request, template, context)


#@login_required
def post_model_update_view(request, id=None):
    obj = get_object_or_404(PostModel, id=id)

    form = PostModelForm(request.POST or None, instance=obj)
    context = {
        'objects': obj,
        'form': form,
    }
    if form.is_valid():
        obj = form.save(commit=False)
        obj.save()
        messages.success(request, 'Update Post!')
        return HttpResponseRedirect('/blog/{num}'.format(num=obj.id))

    template = 'blog/update_view.html'
    return render(request, template, context)


#@login_required
def post_model_create_view(request):
    form = PostModelForm(request.POST or None)
    context = {
        'form': form,
    }
    if form.is_valid():
        obj = form.save(commit=False)
        obj.save()
        messages.success(request, 'Created a new blog.')
        context = {
            'form': PostModelForm(request.POST or None)
        }
        # return HttpResponseRedirect('/blog/{num}'.format(num=obj.id))

    template = 'blog/create_view.html'
    return render(request, template, context)


#@login_required
def post_model_detail_view(request, id=None):
    print(id)
    obj = get_list_or_404(PostModel, id=id)

    context = {
        'objects': obj,
    }
    template = 'blog/list_detail_view.html'
    return render(request, template, context)


#@login_required
def post_model_list_view(request):
    query= request.GET.get('q', None)
    qs = PostModel.objects.all()
    if query is not None:
        qs=qs.filter(
            Q(title__icontains=query)|
            Q(content__icontains=query)|
            Q(slug__icontains=query)
            )
    context = {
        'object_list': qs,
    }
    template = 'blog/list_view.html'

    return render(request, template, context)


#'@login_required(login_url='/login/')
def login_required_view(request):
    print(request.user)
    qs = PostModel.objects.all()
    context = {
        'object_list': qs,
    }
    if request.user.is_authenticated:
        template = 'blog/list_view.html'
    else:
        template = 'blog/list_view_public.html'
        # Http404
        return HttpResponseRedirect('/login')

    return render(request, template, context)


def post_model_robust_view(request, id=None):
    obj = None
    context = {}
    success_message = 'New post created'
    if id is not None:
        'object is could be created'
        template = 'create_view.html'

    else:
        if id is not None:
            'obj probaly exists'
        obj = get_list_or_404(PostModel, id=id)
        success_message = 'New post created'
        template = 'blog/list_detail_view.html'
        context['object'] = obj
        if 'edit' in request.get_full_path():
            template = 'blog/update_view.html'

        if 'delete' in request.get_full_path():
            template = 'blog/delete_view.html'
            if request.method == 'POST':
                obj.delete()
                messages.success(request, 'Delete Post!')
                return HttpResponseRedirect('/blog/')

    #if 'edit' in request.get_full_path() or 'create' in request.get_full_path():
    form = PostModelForm(request.POST or None, instance=obj)
    context['form'] = form
    if form.is_valid():
        obj = form.save(commit=False)
        obj.save()
        messages.success(request, success_message)
        if obj is not None:
            return HttpResponseRedirect('/blog/{num}'.format(num=obj.id))
        context['form'] = PostModelForm()

    return render(request, template, context)
