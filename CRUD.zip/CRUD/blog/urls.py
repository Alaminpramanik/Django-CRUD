from django.urls import path


from .views import (
    post_model_list_view,
    post_model_detail_view,
    post_model_create_view,
    post_model_delete_view,
    post_model_update_view,

    )

urlpatterns = [
    path('blog/', post_model_list_view, name='home'),
    path('blog/<int:id>/', post_model_detail_view, name='detail'),
    path('blog/create/', post_model_create_view, name='create'),
    path('blog/delete/', post_model_delete_view, name='delete'),
    path('blog/delete/', post_model_update_view, name='delete'),

]